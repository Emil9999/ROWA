from . import pins

pins.readPinsFromJson()